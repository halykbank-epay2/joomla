<?php

defined('_JEXEC') or die();
define('_JSHOP_HBEPAY_CLIENT_ID', "Client ID");
define('_JSHOP_HBEPAY_CLIENT_SECRET',"Client Secret");
define('_JSHOP_HBEPAY_DESCRIPTION',"Description");
define('_JSHOP_HBEPAY_MODE',"Test mode");
define('_JSHOP_HBEPAY_TERMINAL',"Terminal");
define('_JSHOP_HBEPAY_BACKLINK',"Backlink");
define('_JSHOP_HBEPAY_FAILURE_BACKLINK',"Failure backlink");
define('_JSHOP_HBEPAY_POSTLINK',"Postlink");
define('_JSHOP_HBEPAY_FAILURE_POSTLINK',"Failure postlink");
