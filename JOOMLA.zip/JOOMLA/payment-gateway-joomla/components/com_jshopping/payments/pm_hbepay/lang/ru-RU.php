<?php

defined('_JEXEC') or die();
define('_JSHOP_HBEPAY_CLIENT_ID', "ID клиента");
define('_JSHOP_HBEPAY_CLIENT_SECRET',"Секретный ключ");
define('_JSHOP_HBEPAY_DESCRIPTION',"Описание");
define('_JSHOP_HBEPAY_MODE',"Тестовый режим");
define('_JSHOP_HBEPAY_TERMINAL',"Терминал");
define('_JSHOP_HBEPAY_BACKLINK',"Backlink");
define('_JSHOP_HBEPAY_FAILURE_BACKLINK',"Failure backlink");
define('_JSHOP_HBEPAY_POSTLINK',"Postlink");
define('_JSHOP_HBEPAY_FAILURE_POSTLINK',"Failure postlink");
