INSERT INTO `#__jshopping_payment_method` (`name_en-GB`, `payment_code`, `payment_class`, `scriptname`, `payment_publish`, `payment_ordering`, `payment_params`, `payment_type`, `price`, `price_type`, `show_descr_in_email`) VALUES
('HBepay', 'hbepay', 'pm_hbepay' , 'pm_hbepay', 1, 3, '\n\n', 2, 0.00, 1, 0);



